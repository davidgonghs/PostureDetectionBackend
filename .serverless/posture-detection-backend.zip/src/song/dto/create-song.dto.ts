export class CreateSongDto {}
