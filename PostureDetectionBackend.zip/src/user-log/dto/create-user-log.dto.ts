export class CreateUserLogDto {}
